from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import Post, Comment, Like, Follow
from django.contrib.auth.decorators import login_required

def index(request):
    posts = Post.objects.all().order_by('-created_at')
    return render(request, 'platformapp/index.html', {'posts': posts})
